import sqlite3

# สร้างฐานข้อมูลและตาราง
def initialize_db():
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
    )''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS todos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category_id INTEGER,
        status TEXT NOT NULL CHECK (status IN ('Pending', 'Completed')),
        FOREIGN KEY (category_id) REFERENCES categories (id)
    )''')
    
    conn.commit()
    conn.close()

# การจัดการหมวดหมู่
def add_category(name):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO categories (name) VALUES (?)', (name,))
    conn.commit()
    conn.close()

def rename_category(category_id, new_name):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE categories SET name = ? WHERE id = ?', (new_name, category_id))
    conn.commit()
    conn.close()

def delete_category(category_id):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM categories WHERE id = ?', (category_id,))
    cursor.execute('UPDATE todos SET category_id = NULL WHERE category_id = ?', (category_id,))
    conn.commit()
    conn.close()

def list_categories():
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    conn.close()
    return categories

# การจัดการงาน
def add_todo(title, category_id):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO todos (title, category_id, status) VALUES (?, ?, ?)', (title, category_id, 'Pending'))
    conn.commit()
    conn.close()

def update_todo(todo_id, new_title):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE todos SET title = ? WHERE id = ?', (new_title, todo_id))
    conn.commit()
    conn.close()

def delete_todo(todo_id):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM todos WHERE id = ?', (todo_id,))
    conn.commit()
    conn.close()

def list_todos_by_category(category_id):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM todos WHERE category_id = ?', (category_id,))
    todos = cursor.fetchall()
    conn.close()
    return todos

# การปรับสถานะของงาน
def update_todo_status(todo_id, status):
    conn = sqlite3.connect('todo_app.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE todos SET status = ? WHERE id = ?', (status, todo_id))
    conn.commit()
    conn.close()

# ฟังก์ชันหลัก
if __name__ == "__main__":
    initialize_db()
    # ตัวอย่างการใช้งาน
    add_category('Work')
    add_category('Personal')
    print("Categories:", list_categories())
    
    add_todo('Finish report', 1)
    print("Todos in Work category:", list_todos_by_category(1))
    
    update_todo_status(1, 'Completed')
    print("Todos in Work category after status update:", list_todos_by_category(1))
